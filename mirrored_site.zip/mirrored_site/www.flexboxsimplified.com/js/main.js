const enrollBtns = document.querySelectorAll(".enroll");
const prices = document.querySelectorAll(".product__price");

Paddle.Setup({
  vendor: 168444,
  eventCallback: function (data) {
    if (data.event === "Checkout.Loaded") {
      fathom.trackGoal("8ANFFCYH", 0);
    }
    if (data.event === "Checkout.Complete") {
      fathom.trackGoal("ZAUFTAAD", 3500);
    }
  },
});

function openCheckout() {
  Paddle.Checkout.open({ product: 822927 });
}

enrollBtns.forEach((button) => {
  button.addEventListener("click", openCheckout, false);
});
